---
name: CampusEats
colors:
  surface: '#f7faf6'
  surface-dim: '#d8dbd7'
  surface-bright: '#f7faf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f1'
  surface-container: '#ecefeb'
  surface-container-high: '#e6e9e5'
  surface-container-highest: '#e0e3e0'
  on-surface: '#181c1a'
  on-surface-variant: '#3f4940'
  inverse-surface: '#2d312f'
  inverse-on-surface: '#eef1ee'
  outline: '#6f7a6f'
  outline-variant: '#becabd'
  surface-tint: '#006d37'
  primary: '#006a36'
  on-primary: '#ffffff'
  primary-container: '#188648'
  on-primary-container: '#f6fff4'
  inverse-primary: '#77db94'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#1c693f'
  on-tertiary: '#ffffff'
  tertiary-container: '#398256'
  on-tertiary-container: '#f6fff4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#93f8ae'
  primary-fixed-dim: '#77db94'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#a7f3be'
  tertiary-fixed-dim: '#8cd7a3'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#00522d'
  background: '#f7faf6'
  on-background: '#181c1a'
  surface-variant: '#e0e3e0'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Epilogue
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system targets students, faculty, and administrative staff across university and high school campuses in Burkina Faso. It establishes an energetic, approachable, and highly dependable mobile experience tailored to fast-paced campus environments where lunch queues can become bottlenecks. The emotional intent is clarity, punctuality, and relief—giving learners and staff assurance that their meals are secured and effortlessly claimable via QR codes.

The aesthetic blends Modern Material 3 principles with local utility: generous whitespace, high-legibility touchpoints, clear visual hierarchy, and tactile cues suited for bright outdoor viewing on mobile displays. Visual components balance crisp usability with warm vitality to make campus dining intuitive, rapid, and welcoming.

## Colors

The palette draws from natural vitality and appetite stimulation, balanced against neutral backgrounds engineered for readability in varying lighting environments.

- **Primary Green (`#1F8A4C`)**: Drives core interactive affordances, active navigation items, completed states, and primary actions.
- **Primary Dark (`#14633A`)**: Used for focused states, pressed button feedback, and high-emphasis visual accents.
- **Accent Warm Orange (`#F59E0B`)**: Drives attention to specials, active ordering timers, warning callouts, and secondary highlights.
- **Neutral Canvas (`#F7F8F5`)**: A soft off-white surface minimizing glare during direct midday sunlight.
- **Surface Layer (`#FFFFFF`)**: Pure white containers ensuring sharp contrast for cards, menus, and sheets.
- **Text Layers**: Text Main (`#1B1F1D`) ensures AA/AAA compliant legibility on all light containers; Text Secondary (`#6B726E`) communicates supplementary metadata and nutritional notes without visual competition.
- **Functional Semantics**:
  - Success: `#22A559` (Order ready, successful validation)
  - Warning: `#F59E0B` (Queue delays, prep times)
  - Error: `#D93636` (Payment failed, expired token)
  - Info: `#2F80ED` (Canteen service updates, closing times)

## Typography

Typography establishes an immediate hierarchy across canteen menus, order progress indicators, and fast-paced interaction screens. 

- **Display & Headline Roles**: Powered by a geometric, expressive grotesque (`Epilogue` matching the energetic structure requested for modern mobile interfaces), emphasizing meal names, pricing totals, and greeting headlines. Weight distribution leans firmly on semi-bold (`600`) and bold (`700`).
- **Body & Metadata Roles**: Standardized on `Inter` for clarity in French language contractions, currency labels (FCFA), and ingredient lists.
- **Label Roles**: Set in medium/semi-bold uppercase or title-case to maintain readability across tags, category chips, status pills, and bottom navigation labels.

## Layout & Spacing

The layout operates primarily on a 4-column fluid mobile grid anchored by a 16px (`1rem`) lateral screen margin. Spacing increments strictly adhere to an 8pt base unit (with 4px half-steps for compact badge alignment).

- **Mobile Viewport (Primary)**: 16px lateral padding ensures that all interactive triggers sit cleanly inside standard mobile device safe zones. Gutters between food cards and horizontal list items are locked at 12px (`0.75rem`) to 16px (`1rem`) to support rapid flick scrolling.
- **Tablet / Large Handheld Adapters**: Adapts into a 6-to-8 column layout where dish listing cards shift from vertical stacked rows into a structured 2-column or 3-column meal selection grid.
- **Safe Area Insets**: Dynamic padding incorporates top notches and the persistent 64px bottom navigation bar + home indicator clearance.

## Elevation & Depth

Visual depth follows an ambient, softened elevation model inspired by Material 3, avoiding harsh drop shadows in favor of diffused, tinted contact shadows.

- **Level 0 (Flat Canvas)**: `#F7F8F5` base background for views and scroll areas.
- **Level 1 (Card & Content Containers)**: Surface `#FFFFFF` with a faint bounding outline (`rgba(27, 31, 29, 0.05)`) and an ultra-soft drop shadow (`0 2px 8px rgba(27, 31, 29, 0.04)`).
- **Level 2 (Modals, Overlays & Mon QR Sheet)**: Surface `#FFFFFF` with elevated blur (`0 8px 24px rgba(20, 99, 58, 0.10)`), bringing critical validation cues closer to the user's focus.
- **Level 3 (Sticky Bottom Bar & Floats)**: Persistent bottom navigation uses top edge separation with `0 -2px 12px rgba(27, 31, 29, 0.06)` to create distinct layering above scrolling menus.

## Shapes

The design system enforces a rounded aesthetic tailored to comfort and tactile responsiveness:

- **Cards & Modal Sheets**: Structured with a 16px (`1rem`) border radius (`rounded-lg`) to soften meal photography and order summaries.
- **Interactive Buttons**: Standardized at 12px border radius for ergonomic finger targets.
- **Chips, Badges & QR Floating Actions**: Fully pill-shaped (`9999px`) to visually differentiate quick state metadata from tappable card surfaces.
- **Image Containers**: Match their parent card corners at the top edge (16px) with square inner bottoms when bordered by content.

## Components

### Buttons
- **Primary Action**: 48px minimum height, 12px radius, filled with Primary Green (`#1F8A4C`), text `#FFFFFF` in `label-lg`. Pressed state transitions to Primary Dark (`#14633A`). Full width on checkout and QR generation steps.
- **Secondary / Ghost Action**: 48px height, 12px radius, `#FFFFFF` background with 1px border (`#1F8A4C`), text `#1F8A4C`.
- **Destructive / Error**: Soft tint red background with bold `#D93636` typography.

### Chips & Badges
- **Category Filter Chips**: Pill-shaped (`rounded-full`), height 36px, horizontal padding 16px. Inactive state: `#FFFFFF` with a subtle neutral border. Active state: `#1F8A4C` fill with white text.
- **Status Badges**: Pill-shaped, height 24px, 8px padding. Tinted background (15% opacity of state color) combined with solid text:
  - *En attente*: Warning tint (`#F59E0B`).
  - *Prêt pour retrait*: Success tint (`#22A559`).
  - *Récupéré*: Neutral secondary (`#6B726E`).

### Canteen Food Cards
- **Structure**: Surface `#FFFFFF`, 16px radius, subtle border. Includes a 120px height top aspect banner for the dish image, badge overlay for price (e.g., "1 250 FCFA" in Accent Warm Orange `#F59E0B`), meal title in `headline-sm`, preparation time badge, and quick add-to-cart circular button (40px).

### Bottom Navigation Bar
- **4 Tab Anchors**:
  1. *Accueil / Menu* (Fork & Spoon icon)
  2. *Mes Commandes* (Receipt icon)
  3. *Mon QR / Retrait* (Prominent center-weighted QR badge)
  4. *Profil* (User avatar icon)
- Fixed height: 64px + device home bar inset. Background `#FFFFFF` with subtle top shadow. Active item: `#1F8A4C` icon and label (`label-sm`); Inactive item: `#6B726E`.

### Form & Input Fields
- Height 48px, 12px radius, `#FFFFFF` surface with a 1px border (`rgba(27, 31, 29, 0.15)`). Focused state highlights with a 2px `#1F8A4C` border. Helper text and input labels rendered in `body-sm`.

### QR Pickup Screen
- High-contrast white card containing the active dynamic QR code (size min 220x220px) surrounded by 16px pure white margin to guarantee instant scanner detection in cafeteria lines. Direct textual pickup PIN code underneath in `headline-md` for backup manual entry.

### State Variants
- **Skeleton Loaders**: Base `#EAECE7` shimmering to `#F7F8F5` across food cards, price tags, and hero banners.
- **Empty States**: Centered friendly vector illustration, title in `headline-md`, supporting text in French (e.g., *"Aucune commande en cours"*), accompanied by a primary button directing the user back to the menu.
- **Error State**: Illustrated warning container, explicit explanatory copy in French, paired with an emphatic primary reload action button labeled *"Réessayer"*.